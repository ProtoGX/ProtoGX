import express from 'express';
import cors from 'cors';

const app = express();
const PORT = Number(process.env.PORT || 4000);

app.use(
  cors({
    origin: true,
    credentials: false
  })
);

app.use(express.json());

const users = [
  {
    id: 1,
    username: 'Privet',
    email: 'privet@gmail.com',
    password: 'privet228',
    role: 'student',
    ageGroup: '11-13',
    avatar: '👨‍💻',
    level: 4,
    xp: 780,
    streak: 6
  }
];

const modules = [
  {
    id: 1,
    title: 'Введение в Python',
    ageGroup: '11-13',
    progress: 66,
    description: 'Переменные, типы данных, print() и input().'
  },
  {
    id: 2,
    title: 'Условия и логика',
    ageGroup: '11-13',
    progress: 33,
    description: 'if / else и логические операторы.'
  }
];

const leaderboard = [
  { place: 1, username: 'PixelFox', xp: 4120, level: 10 },
  { place: 2, username: 'Privet', xp: 780, level: 4 },
  { place: 3, username: 'CodeCat', xp: 760, level: 4 }
];

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/auth/register', (req, res) => {
  const { username, email, password, ageGroup } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ message: 'Заполните все обязательные поля' });
  }

  if (users.some((user) => user.email === email)) {
    return res.status(409).json({ message: 'Пользователь уже существует' });
  }

  const user = {
    id: users.length + 1,
    username,
    email,
    password,
    role: 'student',
    ageGroup: ageGroup || '11-13',
    avatar: '👨‍💻',
    level: 1,
    xp: 0,
    streak: 1
  };

  users.push(user);

  return res.status(201).json({
    token: `demo-token-${user.id}`,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      ageGroup: user.ageGroup,
      avatar: user.avatar,
      level: user.level,
      xp: user.xp,
      streak: user.streak
    }
  });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find((item) => item.email === email && item.password === password);

  if (!user) {
    return res.status(401).json({ message: 'Неверный Gmail или пароль' });
  }

  return res.json({
    token: `demo-token-${user.id}`,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      ageGroup: user.ageGroup,
      avatar: user.avatar,
      level: user.level,
      xp: user.xp,
      streak: user.streak
    }
  });
});

app.get('/api/users/me', (_req, res) => {
  const user = users[0];

  res.json({
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    ageGroup: user.ageGroup,
    avatar: user.avatar,
    level: user.level,
    xp: user.xp,
    streak: user.streak
  });
});

app.get('/api/modules', (_req, res) => {
  res.json(modules);
});

app.get('/api/leaderboard', (_req, res) => {
  res.json(leaderboard);
});

app.get('/api/parent/children', (_req, res) => {
  res.json([
    {
      id: 1,
      username: 'Privet',
      level: 4,
      xp: 780,
      streak: 6
    }
  ]);
});

app.get('/api/parent/children/:id/stats', (req, res) => {
  res.json({
    childId: Number(req.params.id),
    completedLessons: 8,
    averageScore: 84,
    minutesSpent: 200
  });
});

app.post('/api/tasks/:id/submit', (req, res) => {
  const { code, expectedSnippet } = req.body;

  const passed =
    typeof code === 'string' &&
    typeof expectedSnippet === 'string' &&
    code.includes(expectedSnippet);

  if (passed) {
    return res.json({
      passed: true,
      message: 'Задание принято. Начислено 30 XP.'
    });
  }

  return res.json({
    passed: false,
    message: `Пока не хватает ключевого элемента: ${expectedSnippet}. Проверь решение ещё раз.`
  });
});

app.post('/api/quizzes/:id/submit', (req, res) => {
  const { answers, correctAnswers } = req.body;

  const total = Array.isArray(correctAnswers) ? correctAnswers.length : 0;
  let correct = 0;

  if (Array.isArray(answers) && Array.isArray(correctAnswers)) {
    answers.forEach((answer, index) => {
      if (answer === correctAnswers[index]) {
        correct += 1;
      }
    });
  }

  const score = total === 0 ? 0 : Math.round((correct / total) * 100);

  res.json({
    score,
    passed: score >= 70
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`ProtoGX API started on http://0.0.0.0:${PORT}`);
});