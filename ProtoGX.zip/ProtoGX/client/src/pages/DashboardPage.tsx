import { Link } from 'react-router-dom';
import { modules } from '../data/mock';
import type { User } from '../types';

interface Props {
  user: User;
}

export default function DashboardPage({ user }: Props) {
  const currentModule = modules[0];
  const currentLesson = currentModule.lessons[0];

  return (
    <div>
      <section className="page-header">
        <div>
          <h1>Привет, {user.username} {user.avatar}</h1>
          <p>Продолжай путь от первых команд к собственным проектам.</p>
        </div>
        <div className="xp-card">
          <strong>Уровень {user.level}</strong>
          <p>{user.xp} XP</p>
          <div className="progress-line"><span style={{ width: '78%' }} /></div>
        </div>
      </section>

      <section className="dashboard-grid">
        <div className="card highlight-card">
          <span className="badge">Продолжить обучение</span>
          <h2>{currentLesson.title}</h2>
          <p>{currentLesson.summary}</p>
          <Link className="primary-button inline-block" to={`/lesson/${currentLesson.id}`}>
            Открыть урок
          </Link>
        </div>

        <div className="card stat-card">
          <h3>Streak</h3>
          <p>{user.streak} дней подряд</p>
        </div>

        <div className="card stat-card">
          <h3>Daily Quest</h3>
          <p>Реши 2 задачи и пройди 1 урок</p>
        </div>

        <div className="card stat-card">
          <h3>Достижения</h3>
          <p>Первый код, Без ошибок, Марафон</p>
        </div>
      </section>

      <section className="card">
        <div className="section-title-row">
          <h2>Карта модулей</h2>
          <Link to="/modules">Все модули</Link>
        </div>
        <div className="module-grid">
          {modules.map((module) => (
            <article key={module.id} className="module-card">
              <div className="module-top">
                <span className="badge">{module.ageGroup}</span>
                <strong>{module.progress}%</strong>
              </div>
              <h3>{module.title}</h3>
              <p>{module.description}</p>
              <div className="progress-line"><span style={{ width: `${module.progress}%` }} /></div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
