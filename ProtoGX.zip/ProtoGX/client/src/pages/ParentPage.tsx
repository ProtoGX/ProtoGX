export default function ParentPage() {
  return (
    <div className="stack-list">
      <section className="card">
        <span className="badge">Родительский контроль</span>
        <h1>Панель мониторинга</h1>
        <p>Общий прогресс ребёнка, статистика активности и управление доступом к модулям.</p>
      </section>

      <section className="dashboard-grid">
        <div className="card stat-card compact">
          <h3>Пройдено уроков</h3>
          <p>8</p>
        </div>
        <div className="card stat-card compact">
          <h3>Средний балл</h3>
          <p>84%</p>
        </div>
        <div className="card stat-card compact">
          <h3>Время в системе</h3>
          <p>3 ч 20 мин</p>
        </div>
      </section>

      <section className="card">
        <h2>Что уже есть в прототипе</h2>
        <ul className="feature-list">
          <li>Сводка по XP, уровню и streak</li>
          <li>Демонстрационный блок статистики</li>
          <li>Отдельный экран для родителя</li>
          <li>Основа для API статистики ребёнка</li>
        </ul>
      </section>
    </div>
  );
}
