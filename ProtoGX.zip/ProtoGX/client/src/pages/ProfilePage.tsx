import type { User } from '../types';

interface Props {
  user: User;
}

export default function ProfilePage({ user }: Props) {
  return (
    <div className="card profile-page">
      <div className="profile-header">
        <div className="profile-avatar">{user.avatar}</div>
        <div>
          <h1>{user.username}</h1>
          <p>{user.email}</p>
          <span className="badge">Уровень {user.level}</span>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="card stat-card compact">
          <h3>XP</h3>
          <p>{user.xp}</p>
        </div>
        <div className="card stat-card compact">
          <h3>Streak</h3>
          <p>{user.streak} дней</p>
        </div>
        <div className="card stat-card compact">
          <h3>Роль</h3>
          <p>{user.role}</p>
        </div>
      </div>

      <section>
        <h2>Последние достижения</h2>
        <div className="achievement-grid">
          <div className="achievement-item">🏅 Первый код</div>
          <div className="achievement-item">⚡ Без ошибок</div>
          <div className="achievement-item">🔥 Марафон</div>
          <div className="achievement-item">🧩 Исследователь</div>
        </div>
      </section>
    </div>
  );
}
