import { Link } from 'react-router-dom';
import { modules } from '../data/mock';

export default function ModulesPage() {
  return (
    <div>
      <section className="page-header simple">
        <div>
          <h1>Учебные модули</h1>
          <p>В прототип добавлены два демонстрационных модуля и несколько уроков.</p>
        </div>
      </section>

      <div className="stack-list">
        {modules.map((module) => (
          <section key={module.id} className="card">
            <div className="section-title-row">
              <div>
                <span className="badge">Возраст {module.ageGroup}</span>
                <h2>{module.title}</h2>
              </div>
              <strong>{module.progress}%</strong>
            </div>
            <p>{module.description}</p>
            <div className="progress-line"><span style={{ width: `${module.progress}%` }} /></div>
            <div className="lesson-list">
              {module.lessons.map((lesson) => (
                <article key={lesson.id} className="lesson-item">
                  <div>
                    <h3>{lesson.title}</h3>
                    <p>{lesson.summary}</p>
                  </div>
                  <Link className="secondary-button inline-block" to={`/lesson/${lesson.id}`}>
                    Открыть
                  </Link>
                </article>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
