import Editor from '@monaco-editor/react';
import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { modules } from '../data/mock';
import { getPyodide, runPythonCode } from '../utils/pyRuntime';

export default function LessonPage() {
  const { lessonId } = useParams();
  const lesson = useMemo(
    () => modules.flatMap((module) => module.lessons).find((item) => item.id === Number(lessonId)),
    [lessonId]
  );

  const [code, setCode] = useState(lesson?.starterCode ?? '');
  const [statusText, setStatusText] = useState('');
  const [programOutput, setProgramOutput] = useState('');
  const [programError, setProgramError] = useState('');
  const [runtimeReady, setRuntimeReady] = useState(false);
  const [runtimeLoading, setRuntimeLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [quizAnswer, setQuizAnswer] = useState<number | null>(null);

  useEffect(() => {
    let active = true;

    setRuntimeLoading(true);
    getPyodide()
      .then(() => {
        if (!active) {
          return;
        }
        setRuntimeReady(true);
        setStatusText('Среда Python загружена. Можно запускать код.');
      })
      .catch((error) => {
        if (!active) {
          return;
        }
        setRuntimeReady(false);
        setStatusText(error instanceof Error ? error.message : 'Не удалось загрузить среду Python.');
      })
      .finally(() => {
        if (active) {
          setRuntimeLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, []);

  if (!lesson) {
    return (
      <div className="card">
        <h1>Урок не найден</h1>
      </div>
    );
  }

  const executeCode = async () => {
    setActionLoading(true);
    setStatusText('Запускаем программу...');
    setProgramOutput('');
    setProgramError('');

    const execution = await runPythonCode(code);

    setProgramOutput(execution.stdout.trimEnd());
    setProgramError(execution.stderr.trimEnd());

    if (execution.ok) {
      setStatusText('Код выполнен без ошибок.');
    } else {
      setStatusText('Во время выполнения возникла ошибка.');
    }

    setActionLoading(false);
  };

  const checkSolution = async () => {
    setActionLoading(true);
    setStatusText('Проверяем решение...');
    setProgramOutput('');
    setProgramError('');

    const execution = await runPythonCode(code);
    const actualOutput = execution.stdout.trim();
    const expectedOutput = lesson.expectedOutput.trim();

    setProgramOutput(execution.stdout.trimEnd());
    setProgramError(execution.stderr.trimEnd());

    if (!execution.ok) {
      setStatusText('Решение не прошло: код завершился с ошибкой.');
      setActionLoading(false);
      return;
    }

    if (actualOutput === expectedOutput) {
      setStatusText(`${lesson.successMessage} Начислено 30 XP.`);
    } else {
      setStatusText(
        `Пока ответ не совпадает. Ожидаемый вывод: "${expectedOutput}". Сейчас программа вывела: "${actualOutput || 'пусто'}".`
      );
    }

    setActionLoading(false);
  };

  const checkQuiz = () => {
    if (quizAnswer === null) {
      setStatusText('Сначала выберите ответ в мини-тесте.');
      return;
    }

    const correctIndex = lesson.quiz[0].correctIndex;
    const score = quizAnswer === correctIndex ? 100 : 0;
    setStatusText(`Тест: ${score}%. ${score === 100 ? 'Ответ верный.' : 'Попробуйте ещё раз.'}`);
  };

  return (
    <div className="lesson-layout">
      <section className="card theory-card">
        <span className="badge">Урок</span>
        <h1>{lesson.title}</h1>
        <p>{lesson.summary}</p>

        <div className="theory-list">
          {lesson.theory.map((item) => (
            <div key={item} className="theory-item">
              {item}
            </div>
          ))}
        </div>

        <section className="quiz-block">
          <h2>Мини-тест</h2>
          <p>{lesson.quiz[0].question}</p>
          <div className="options-list">
            {lesson.quiz[0].options.map((option, index) => (
              <label key={option} className="option-item">
                <input
                  type="radio"
                  name="quiz"
                  checked={quizAnswer === index}
                  onChange={() => setQuizAnswer(index)}
                />
                {option}
              </label>
            ))}
          </div>
          <button className="secondary-button" onClick={checkQuiz}>
            Проверить тест
          </button>
        </section>
      </section>

      <section className="card editor-card">
        <div className="section-title-row">
          <h2>Практика - Monaco Editor</h2>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            <button className="secondary-button" onClick={executeCode} disabled={!runtimeReady || actionLoading}>
              {runtimeLoading ? 'Загрузка среды...' : 'Запустить код'}
            </button>
            <button className="primary-button" onClick={checkSolution} disabled={!runtimeReady || actionLoading}>
              Проверить решение
            </button>
          </div>
        </div>

        <div className="editor-wrap">
          <Editor
            height="420px"
            defaultLanguage="python"
            value={code}
            onChange={(value) => setCode(value ?? '')}
            theme="vs-dark"
            options={{
              fontSize: 15,
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
              wordWrap: 'on'
            }}
          />
        </div>

        <div className="result-box">
          <strong>Статус</strong>
          <p>{statusText || 'Пока запуска не было.'}</p>

          <strong>Ожидаемый вывод</strong>
          <p>{lesson.expectedOutput}</p>

          <strong>Вывод программы</strong>
          <pre style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{programOutput || 'Пока пусто.'}</pre>

          <strong style={{ display: 'block', marginTop: '16px' }}>Ошибки</strong>
          <pre style={{ whiteSpace: 'pre-wrap', margin: 0 }}>{programError || 'Ошибок нет.'}</pre>
        </div>
      </section>
    </div>
  );
}