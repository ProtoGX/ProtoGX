import { leaderboard } from '../data/mock';

export default function LeaderboardPage() {
  return (
    <div className="card">
      <div className="section-title-row">
        <div>
          <span className="badge">Top 50</span>
          <h1>Глобальный рейтинг</h1>
        </div>
        <div className="tabs-mini">
          <button className="active">Неделя</button>
          <button>Месяц</button>
          <button>Все время</button>
        </div>
      </div>

      <div className="leaderboard-table">
        <div className="leaderboard-row header">
          <span>Место</span>
          <span>Никнейм</span>
          <span>Уровень</span>
          <span>XP</span>
        </div>
        {leaderboard.map((item) => (
          <div key={item.place} className="leaderboard-row">
            <span>#{item.place}</span>
            <span>{item.username}</span>
            <span>{item.level}</span>
            <span>{item.xp}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
