import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiUrl } from '../config';
import type { AgeGroup, User } from '../types';

interface AuthPageProps {
  onLogin: (user: User, token: string) => void;
}

export default function AuthPage({ onLogin }: AuthPageProps) {
  const navigate = useNavigate();

  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [ageGroup, setAgeGroup] = useState<AgeGroup>('11-13');
  const [error, setError] = useState('');

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError('');

    try {
      const endpoint = isRegister ? '/api/auth/register' : '/api/auth/login';
      const payload = isRegister
        ? { username, email, password, ageGroup }
        : { email, password };

      const response = await fetch(apiUrl(endpoint), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const contentType = response.headers.get('content-type') || '';
      const rawText = await response.text();

      if (!contentType.includes('application/json')) {
        throw new Error(`Сервер вернул не JSON. Ответ: ${rawText.slice(0, 120)}`);
      }

      const data = JSON.parse(rawText);

      if (!response.ok) {
        throw new Error(data?.message || (isRegister ? 'Ошибка регистрации' : 'Ошибка входа'));
      }

      onLogin(data.user, data.token);
      navigate('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Не удалось выполнить действие');
    }
  };

  return (
    <div className="auth-page">
      <section className="hero-card">
        <span className="badge">Орен ИТ 2026</span>
        <h1>ProtoGX</h1>
        <p>
          Платформа для обучения программированию: модули, практика, рейтинг,
          достижения и родительский контроль.
        </p>

        <div className="hero-grid">
          <div className="small-card">
            <strong>7-10 лет</strong>
            <p>Блочное программирование и игровые задания</p>
          </div>
          <div className="small-card">
            <strong>11-13 лет</strong>
            <p>Переход к Python и первым алгоритмам</p>
          </div>
          <div className="small-card">
            <strong>14-15 лет</strong>
            <p>Текстовый код, практика и мини-проекты</p>
          </div>
        </div>
      </section>

      <section className="auth-card">
        <div className="auth-switcher">
          <button
            type="button"
            className={!isRegister ? 'active' : ''}
            onClick={() => {
              setIsRegister(false);
              setError('');
              setEmail('');
              setPassword('');
            }}
          >
            Вход
          </button>

          <button
            type="button"
            className={isRegister ? 'active' : ''}
            onClick={() => {
              setIsRegister(true);
              setError('');
              setUsername('');
              setEmail('');
              setPassword('');
              setAgeGroup('11-13');
            }}
          >
            Регистрация
          </button>
        </div>

        <div className="auth-panel-head">
          <span className="badge">{isRegister ? 'Новый аккаунт' : 'Добро пожаловать'}</span>
          <h2>{isRegister ? 'Регистрация' : 'Вход'}</h2>
          <p>
            {isRegister
              ? 'Заполните форму, чтобы создать новый аккаунт.'
              : 'Введите Gmail и пароль, чтобы войти в систему.'}
          </p>
        </div>

        <form onSubmit={submit} className="auth-form">
          {!isRegister && (
            <>
              <label>
                Gmail
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </label>

              <label>
                Пароль
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={6}
                  required
                />
              </label>
            </>
          )}

          {isRegister && (
            <>
              <label>
                Имя или никнейм
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </label>

              <label>
                Gmail
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </label>

              <label>
                Пароль
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={6}
                  required
                />
              </label>

              <label>
                Возрастная группа
                <select value={ageGroup} onChange={(e) => setAgeGroup(e.target.value as AgeGroup)}>
                  <option value="7-10">7-10 лет</option>
                  <option value="11-13">11-13 лет</option>
                  <option value="14-15">14-15 лет</option>
                </select>
              </label>
            </>
          )}

          {error && <p className="error-text">{error}</p>}

          <button className="primary-button" type="submit">
            {isRegister ? 'Создать аккаунт' : 'Войти'}
          </button>
        </form>
      </section>
    </div>
  );
}