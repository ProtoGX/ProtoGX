import { useMemo, useState } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import LeaderboardPage from './pages/LeaderboardPage';
import LessonPage from './pages/LessonPage';
import ModulesPage from './pages/ModulesPage';
import ParentPage from './pages/ParentPage';
import ProfilePage from './pages/ProfilePage';
import type { User } from './types';

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    const raw = localStorage.getItem('codequest_user');
    return raw ? (JSON.parse(raw) as User) : null;
  });

  const login = (nextUser: User, token: string) => {
    localStorage.setItem('codequest_user', JSON.stringify(nextUser));
    localStorage.setItem('codequest_token', token);
    setUser(nextUser);
  };

  const logout = () => {
    localStorage.removeItem('codequest_user');
    localStorage.removeItem('codequest_token');
    setUser(null);
  };

  const protectedLayout = useMemo(
    () => (
      <ProtectedRoute user={user}>
        <Layout user={user} onLogout={logout} />
      </ProtectedRoute>
    ),
    [user]
  );

  return (
    <Routes>
      <Route path="/" element={<AuthPage onLogin={login} />} />
      <Route path="/" element={protectedLayout}>
        <Route path="dashboard" element={user ? <DashboardPage user={user} /> : <Navigate to="/" replace />} />
        <Route path="modules" element={<ModulesPage />} />
        <Route path="lesson/:lessonId" element={<LessonPage />} />
        <Route path="leaderboard" element={<LeaderboardPage />} />
        <Route path="parent" element={<ParentPage />} />
        <Route path="profile" element={user ? <ProfilePage user={user} /> : <Navigate to="/" replace />} />
      </Route>
      <Route path="*" element={<Navigate to={user ? '/dashboard' : '/'} replace />} />
    </Routes>
  );
}
