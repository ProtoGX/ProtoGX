export type AgeGroup = '7-10' | '11-13' | '14-15';

export interface User {
  id: number;
  username: string;
  email: string;
  role: 'student' | 'parent' | 'teacher';
  ageGroup: AgeGroup;
  avatar: string;
  level: number;
  xp: number;
  streak: number;
}

export interface LessonQuizItem {
  question: string;
  options: string[];
  correctIndex: number;
}

export interface Lesson {
  id: number;
  moduleId: number;
  title: string;
  summary: string;
  theory: string[];
  starterCode: string;
  expectedOutput: string;
  expectedSnippet?: string;
  successMessage: string;
  xpReward: number;
  quiz: LessonQuizItem[];
}

export interface ModuleMapPosition {
  x: number;
  y: number;
}

export interface ModuleItem {
  id: number;
  title: string;
  ageGroup: AgeGroup;
  progress: number;
  description: string;
  prerequisiteModuleIds: number[];
  mapPosition: ModuleMapPosition;
  rewardId: string;
  lessons: Lesson[];
}

export interface LeaderboardEntry {
  place: number;
  username: string;
  xp: number;
  level: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface ProgressState {
  completedLessonIds: number[];
  completedModuleIds: number[];
  xp: number;
  level: number;
  achievementIds: string[];
  rewardIds: string[];
}