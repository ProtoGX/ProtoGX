import type { LeaderboardEntry, ModuleItem, User } from '../types';

export const demoUser: User = {
  id: 1,
  username: 'Privet',
  email: 'privet@gmail.com',
  role: 'student',
  ageGroup: '11-13',
  avatar: '👨‍💻',
  level: 4,
  xp: 780,
  streak: 6
};

export const modules: ModuleItem[] = [
  {
    id: 1,
    title: 'Введение в Python',
    ageGroup: '11-13',
    progress: 66,
    description: 'Переменные, типы данных, print() и input().',
    lessons: [
      {
        id: 101,
        moduleId: 1,
        title: 'Первая программа',
        summary: 'Пишем первую программу и знакомимся с выводом текста.',
        theory: [
          'Python - язык программирования, который хорошо подходит детям и новичкам.',
          'Функция print() выводит текст на экран.',
          'Теперь код реально запускается, а проверка идёт по настоящему результату программы.'
        ],
        starterCode: 'print("Привет, мир!")',
        expectedOutput: 'Привет, мир!',
        successMessage: 'Решение верное.',
        quiz: [
          {
            question: 'Какая команда выводит текст на экран?',
            options: ['input()', 'print()', 'while', 'for'],
            correctIndex: 1
          }
        ]
      },
      {
        id: 102,
        moduleId: 1,
        title: 'Переменные',
        summary: 'Создаём переменные и выводим их значение.',
        theory: [
          'Переменная - это именованное место хранения данных.',
          'В Python можно создать переменную через знак =.',
          'Значение переменной можно вывести через print().'
        ],
        starterCode: 'name = "Алина"\nprint(name)',
        expectedOutput: 'Алина',
        successMessage: 'Отлично, переменная выведена правильно.',
        quiz: [
          {
            question: 'Что такое переменная?',
            options: ['Кнопка', 'Хранилище данных', 'Браузер', 'Сайт'],
            correctIndex: 1
          }
        ]
      }
    ]
  },
  {
    id: 2,
    title: 'Условия и логика',
    ageGroup: '11-13',
    progress: 33,
    description: 'if / else, сравнение значений и простые решения.',
    lessons: [
      {
        id: 201,
        moduleId: 2,
        title: 'Если... иначе...',
        summary: 'Учимся принимать решения в коде.',
        theory: [
          'Условие позволяет программе выбирать действие.',
          'Если условие истинно - выполняется один блок, иначе - другой.',
          'Это основа логики для игр, квестов и интерактивных заданий.'
        ],
        starterCode:
          'age = 12\nif age >= 10:\n    print("Можно начать")\nelse:\n    print("Нужно подрасти")',
        expectedOutput: 'Можно начать',
        successMessage: 'Условие работает правильно.',
        quiz: [
          {
            question: 'Для чего нужен if?',
            options: ['Для цикла', 'Для условий', 'Для списка', 'Для модуля'],
            correctIndex: 1
          }
        ]
      }
    ]
  }
];

export const leaderboard: LeaderboardEntry[] = [
  { place: 1, username: 'PixelFox', xp: 4120, level: 10 },
  { place: 2, username: 'Privet', xp: 780, level: 4 },
  { place: 3, username: 'CodeCat', xp: 760, level: 4 },
  { place: 4, username: 'LogicKid', xp: 730, level: 4 }
];