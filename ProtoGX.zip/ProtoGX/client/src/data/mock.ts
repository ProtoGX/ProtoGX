import type { Achievement, LeaderboardEntry, ModuleItem, Reward, User } from '../types';

export const demoUser: User = {
  id: 1,
  username: 'Privet',
  email: 'privet@gmail.com',
  role: 'student',
  ageGroup: '11-13',
  avatar: '👨‍💻',
  level: 1,
  xp: 0,
  streak: 1
};

export const achievementsCatalog: Achievement[] = [
  {
    id: 'first-lesson',
    title: 'Первый шаг',
    description: 'Пройден первый урок.',
    icon: '🚀'
  },
  {
    id: 'first-module',
    title: 'Первый модуль',
    description: 'Полностью завершен первый модуль.',
    icon: '📚'
  },
  {
    id: 'xp-250',
    title: 'Разгон',
    description: 'Набрано 250 очков опыта.',
    icon: '⚡'
  },
  {
    id: 'xp-500',
    title: 'Сильный кодер',
    description: 'Набрано 500 очков опыта.',
    icon: '💎'
  },
  {
    id: 'all-modules',
    title: 'Архитектор знаний',
    description: 'Завершены все модули.',
    icon: '👑'
  }
];

export const rewardsCatalog: Reward[] = [
  {
    id: 'reward-editor-theme',
    title: 'Награда: Новая тема редактора',
    description: 'Открывается после первого модуля.',
    icon: '🎨'
  },
  {
    id: 'reward-profile-badge',
    title: 'Награда: Профильный бейдж',
    description: 'Открывается на 3 уровне.',
    icon: '🏅'
  },
  {
    id: 'reward-master-box',
    title: 'Награда: Сундук мастера',
    description: 'Открывается после 500 XP.',
    icon: '🎁'
  },
  {
    id: 'reward-architect-key',
    title: 'Награда: Ключ архитектора',
    description: 'Открывается после завершения всех модулей.',
    icon: '🗝️'
  }
];

export const modules: ModuleItem[] = [
  {
    id: 1,
    title: 'Модуль 1. Старт',
    ageGroup: '11-13',
    progress: 0,
    description: 'Знакомство с Python, вывод текста и базовые команды.',
    prerequisiteModuleIds: [],
    mapPosition: { x: 80, y: 220 },
    rewardId: 'reward-editor-theme',
    lessons: [
      {
        id: 101,
        moduleId: 1,
        title: 'Первая программа',
        summary: 'Пишем первую программу и знакомимся с выводом текста.',
        theory: [
          'Python - это язык программирования, на котором удобно учиться.',
          'Команда print() выводит текст на экран.',
          'Текст обязательно пишется в кавычках.',
          'Когда программа запускается, Python читает команды сверху вниз.'
        ],
        starterCode: `print("Привет, мир!")`,
        expectedOutput: 'Привет, мир!',
        successMessage: 'Первая программа написана верно.',
        xpReward: 40,
        quiz: [
          {
            question: 'Какая команда выводит текст на экран?',
            options: ['print()', 'input()', 'for', 'if'],
            correctIndex: 0
          }
        ]
      },
      {
        id: 102,
        moduleId: 1,
        title: 'Два вывода подряд',
        summary: 'Учимся делать несколько строк вывода.',
        theory: [
          'Если написать две команды print(), то программа выведет две строки.',
          'Каждая новая команда обычно пишется с новой строки.',
          'Python выполняет команды по порядку.'
        ],
        starterCode: `print("Я учусь")
print("в ProtoGX")`,
        expectedOutput: 'Я учусь\nв ProtoGX',
        successMessage: 'Ты научился выводить несколько строк.',
        xpReward: 40,
        quiz: [
          {
            question: 'Что произойдет, если написать две команды print()?',
            options: [
              'Будет ошибка',
              'Выведется две строки',
              'Выведется только первая',
              'Ничего не выведется'
            ],
            correctIndex: 1
          }
        ]
      }
    ]
  },
  {
    id: 2,
    title: 'Модуль 2. Переменные',
    ageGroup: '11-13',
    progress: 0,
    description: 'Переменные, данные и первые вычисления.',
    prerequisiteModuleIds: [1],
    mapPosition: { x: 380, y: 80 },
    rewardId: 'reward-profile-badge',
    lessons: [
      {
        id: 201,
        moduleId: 2,
        title: 'Что такое переменная',
        summary: 'Создаем переменную и выводим ее значение.',
        theory: [
          'Переменная - это именованная ячейка, в которой хранится значение.',
          'Знак = присваивает значение переменной.',
          'После этого переменную можно передать в print().'
        ],
        starterCode: `name = "Алина"
print(name)`,
        expectedOutput: 'Алина',
        successMessage: 'Переменная создана и выведена правильно.',
        xpReward: 55,
        quiz: [
          {
            question: 'Для чего нужна переменная?',
            options: [
              'Для хранения данных',
              'Для удаления кода',
              'Для картинки',
              'Для выхода из программы'
            ],
            correctIndex: 0
          }
        ]
      },
      {
        id: 202,
        moduleId: 2,
        title: 'Простое вычисление',
        summary: 'Складываем числа и выводим результат.',
        theory: [
          'Python умеет работать с числами.',
          'Операция + складывает два значения.',
          'Результат можно сохранить в переменную.'
        ],
        starterCode: `a = 5
b = 7
result = a + b
print(result)`,
        expectedOutput: '12',
        successMessage: 'Вычисление выполнено правильно.',
        xpReward: 55,
        quiz: [
          {
            question: 'Что делает знак + между числами?',
            options: ['Делит', 'Сравнивает', 'Складывает', 'Удаляет'],
            correctIndex: 2
          }
        ]
      }
    ]
  },
  {
    id: 3,
    title: 'Модуль 3. Условия',
    ageGroup: '11-13',
    progress: 0,
    description: 'if, else и логика принятия решений.',
    prerequisiteModuleIds: [1],
    mapPosition: { x: 380, y: 360 },
    rewardId: 'reward-master-box',
    lessons: [
      {
        id: 301,
        moduleId: 3,
        title: 'Первое условие',
        summary: 'Учимся проверять условие и выполнять действие.',
        theory: [
          'Условие позволяет программе решать, что делать.',
          'if выполняет код только если условие истинно.',
          'Отступы в Python очень важны.'
        ],
        starterCode: `age = 12
if age >= 10:
    print("Можно начать")`,
        expectedOutput: 'Можно начать',
        successMessage: 'Условие работает верно.',
        xpReward: 65,
        quiz: [
          {
            question: 'Для чего нужен if?',
            options: ['Для цикла', 'Для условий', 'Для импорта', 'Для удаления'],
            correctIndex: 1
          }
        ]
      },
      {
        id: 302,
        moduleId: 3,
        title: 'if и else',
        summary: 'Добавляем вторую ветку решения.',
        theory: [
          'else выполняется, если условие в if ложно.',
          'Так можно описывать разные сценарии поведения программы.',
          'Это часто используется в играх, проверках и заданиях.'
        ],
        starterCode: `score = 3
if score >= 5:
    print("Отлично")
else:
    print("Попробуй еще")`,
        expectedOutput: 'Попробуй еще',
        successMessage: 'Ветка else работает правильно.',
        xpReward: 65,
        quiz: [
          {
            question: 'Когда выполняется else?',
            options: ['Всегда', 'Когда if истинно', 'Когда if ложно', 'Никогда'],
            correctIndex: 2
          }
        ]
      }
    ]
  },
  {
    id: 4,
    title: 'Модуль 4. Циклы и мини-проект',
    ageGroup: '11-13',
    progress: 0,
    description: 'Циклы for и мини-проект, который открывается только после двух веток.',
    prerequisiteModuleIds: [2, 3],
    mapPosition: { x: 710, y: 220 },
    rewardId: 'reward-architect-key',
    lessons: [
      {
        id: 401,
        moduleId: 4,
        title: 'Первый цикл for',
        summary: 'Повторяем действие несколько раз.',
        theory: [
          'Цикл for нужен, чтобы повторять команды.',
          'range(3) даст три повтора: 0, 1 и 2.',
          'Это удобно, когда нужно много одинаковых действий.'
        ],
        starterCode: `for i in range(3):
    print("Шаг")`,
        expectedOutput: 'Шаг\nШаг\nШаг',
        successMessage: 'Цикл отработал правильно.',
        xpReward: 80,
        quiz: [
          {
            question: 'Для чего нужен цикл for?',
            options: [
              'Для повтора действий',
              'Для рисунка',
              'Для удаления переменной',
              'Для входа на сайт'
            ],
            correctIndex: 0
          }
        ]
      },
      {
        id: 402,
        moduleId: 4,
        title: 'Мини-проект',
        summary: 'Объединяем переменные, условие и цикл в одном задании.',
        theory: [
          'Мини-проект - это объединение нескольких тем.',
          'Так знания соединяются в одну полезную схему.',
          'Если ты проходишь этот урок, значит прошел основную ветку карты.'
        ],
        starterCode: `name = "ProtoGX"
for i in range(2):
    print(name)`,
        expectedOutput: 'ProtoGX\nProtoGX',
        successMessage: 'Мини-проект завершен.',
        xpReward: 100,
        quiz: [
          {
            question: 'Что обычно происходит в мини-проекте?',
            options: [
              'Одна случайная команда',
              'Соединение нескольких тем',
              'Только теория',
              'Только картинка'
            ],
            correctIndex: 1
          }
        ]
      }
    ]
  }
];

export const leaderboard: LeaderboardEntry[] = [
  { place: 1, username: 'PixelFox', xp: 640, level: 6 },
  { place: 2, username: 'Privet', xp: 0, level: 1 },
  { place: 3, username: 'CodeCat', xp: 420, level: 4 }
];