import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import type { User } from '../types';

interface LayoutProps {
  user: User | null;
  onLogout: () => void;
}

export default function Layout({ user, onLogout }: LayoutProps) {
  const navigate = useNavigate();

  const handleLogout = () => {
    onLogout();
    navigate('/');
  };

  return (
    <div className="shell">
      <aside className="sidebar">
        <Link to="/dashboard" className="brand">
          <span className="brand-logo">CQ</span>
          <div>
            <strong>CodeQuest</strong>
            <p>Интерактивное обучение</p>
          </div>
        </Link>

        <nav className="menu">
          <NavLink to="/dashboard">Главная</NavLink>
          <NavLink to="/modules">Модули</NavLink>
          <NavLink to="/leaderboard">Рейтинг</NavLink>
          <NavLink to="/parent">Родителям</NavLink>
          <NavLink to="/profile">Профиль</NavLink>
        </nav>

        {user && (
          <div className="profile-mini">
            <div className="avatar">{user.avatar}</div>
            <div>
              <strong>{user.username}</strong>
              <p>Уровень {user.level}</p>
            </div>
          </div>
        )}

        <button className="secondary-button" onClick={handleLogout}>
          Выйти
        </button>
      </aside>

      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
