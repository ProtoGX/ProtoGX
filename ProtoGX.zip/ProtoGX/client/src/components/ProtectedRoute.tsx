import type { ReactElement } from 'react';
import { Navigate } from 'react-router-dom';
import type { User } from '../types';

interface Props {
  user: User | null;
  children: ReactElement;
}

export default function ProtectedRoute({ user, children }: Props) {
  if (!user) {
    return <Navigate to="/" replace />;
  }

  return children;
}
