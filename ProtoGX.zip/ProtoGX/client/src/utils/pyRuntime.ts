declare global {
  interface Window {
    loadPyodide?: (options?: { indexURL?: string }) => Promise<PyodideLike>;
  }
}

interface PyodideLike {
  globals: {
    set: (name: string, value: unknown) => void;
    delete: (name: string) => void;
  };
  runPythonAsync: (code: string) => Promise<string>;
}

export interface PythonRunResult {
  ok: boolean;
  stdout: string;
  stderr: string;
}

let pyodidePromise: Promise<PyodideLike> | null = null;

function loadScript(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[src="${src}"]`);
    if (existing) {
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error('Не удалось загрузить Pyodide.')), {
        once: true
      });

      if ((existing as HTMLScriptElement).dataset.loaded === 'true') {
        resolve();
      }

      return;
    }

    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.dataset.loaded = 'false';

    script.onload = () => {
      script.dataset.loaded = 'true';
      resolve();
    };

    script.onerror = () => {
      reject(new Error('Не удалось загрузить Pyodide.'));
    };

    document.head.appendChild(script);
  });
}

export async function getPyodide(): Promise<PyodideLike> {
  if (!pyodidePromise) {
    pyodidePromise = (async () => {
      if (!window.loadPyodide) {
        await loadScript('https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js');
      }

      if (!window.loadPyodide) {
        throw new Error('Среда Python не загрузилась.');
      }

      const pyodide = await window.loadPyodide({
        indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/'
      });

      return pyodide;
    })();
  }

  return pyodidePromise;
}

export async function runPythonCode(code: string): Promise<PythonRunResult> {
  try {
    const pyodide = await getPyodide();

    pyodide.globals.set('user_code', code);

    const raw = await pyodide.runPythonAsync(`
import io
import json
import sys
import traceback

_stdout = io.StringIO()
_stderr = io.StringIO()

_prev_stdout = sys.stdout
_prev_stderr = sys.stderr

sys.stdout = _stdout
sys.stderr = _stderr

_ok = True

try:
    exec(user_code, {})
except Exception:
    _ok = False
    traceback.print_exc()
finally:
    sys.stdout = _prev_stdout
    sys.stderr = _prev_stderr

json.dumps({
    "ok": _ok,
    "stdout": _stdout.getvalue(),
    "stderr": _stderr.getvalue()
})
`);

    pyodide.globals.delete('user_code');

    return JSON.parse(raw) as PythonRunResult;
  } catch (error: unknown) {
    return {
      ok: false,
      stdout: '',
      stderr: error instanceof Error ? error.message : 'Не удалось выполнить код.'
    };
  }
}