# CodeQuest - стартовый прототип

Это стартовая версия сайта по ТЗ для хакатона.

Что уже есть:
- React + TypeScript клиент
- Node.js + Express API
- регистрация и вход
- dashboard
- модули и уроки
- Monaco Editor на странице урока
- базовая проверка задания
- мини-тест
- рейтинг
- экран родительского контроля
- Docker Compose для запуска проекта одной командой

## Быстрый запуск через Docker

### 1. Открой проект
Открой папку `codequest-prototype` в Visual Studio Code.

### 2. Запусти контейнеры
```bash
docker compose up -d --build
```

### 3. Открой проект
- сайт: `http://localhost:3000`
- API: `http://localhost:4000/api/health`

### 4. Остановить проект
```bash
docker compose down
```

## Тестовый вход
- Email: `andrey@example.com`
- Пароль: `123456`

## Локальный запуск без Docker

### Сервер
```bash
cd server
npm install
npm run dev
```

Сервер запустится на:
`http://localhost:4000`

### Клиент
Во втором терминале:
```bash
cd client
npm install
npm run dev
```

Клиент запустится на:
`http://localhost:5173`

## Что уже сделано в Docker-версии
- клиент собирается в production-режиме
- клиент раздаётся через Nginx
- запросы `/api` автоматически проксируются на backend
- backend ждёт запросы на `4000` порту
- добавлен healthcheck, чтобы frontend стартовал после backend

## Что делать дальше
Следующий этап:
1. Подключить PostgreSQL.
2. Добавить JWT refresh/access.
3. Перенести данные модулей в БД.
4. Подключить Prisma.
5. Добавить Blockly.
6. Сделать реальные проверки задач.
